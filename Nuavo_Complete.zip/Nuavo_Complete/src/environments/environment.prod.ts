export const environment = {
  production: true,

  dialogflow: {
    angularBot: 'f12104014b3840ca8f11bafe05c38739'
  },
  
  firebase: {
    apiKey: 'AIzaSyDB4eB3WOjTmxhvizKb-wrvCCRrQgPJEj4',
    authDomain: 'nuavo-cwmyoi.firebaseapp.com',
    databaseURL: 'https://nuavo-cwmyoi.firebaseio.com',
    projectId: 'nuavo-cwmyoi',
    storageBucket: 'nuavo-cwmyoi.appspot.com',
    messagingSenderId: '824003767462'
}
};
